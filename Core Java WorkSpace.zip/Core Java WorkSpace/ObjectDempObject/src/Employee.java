
public class Employee 
{
	private int empId;
	private String empName;
	private float empSal;
	public Employee()
	{
		super();
	}
	public Employee(int empId, String empName, float empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	
	public float calcEmpMonsal()
	{
		return empSal;
		
	}
	public float calcEmpAnnSal()
	{
		return empSal*12;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}
	
	@Override
	public boolean equals(Object emp)
	{
		Employee tempE = (Employee)emp;
		if(this.empId == tempE.empId)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public int hashCode()
	{
		return empId;
	}
	

}
