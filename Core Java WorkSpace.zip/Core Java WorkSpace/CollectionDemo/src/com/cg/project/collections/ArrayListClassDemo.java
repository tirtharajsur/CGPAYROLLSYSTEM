package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Collections;
import com.cg.project.beans.Associate;

public class ArrayListClassDemo {
	public static void main(String[] args) {
		ArrayList<Associate> strList  = new ArrayList<>();
		strList.add(new Associate(111,"Zakir","Khan",15000.00));
		strList.add(new Associate(222,"Varun","Thakur",16001.00));
		strList.add(new Associate(333,"Rahul","Subramanian",17002.00));
		strList.add(new Associate(444,"Tanmay","Bhat",18003.00));
		
		Collections.sort(strList);
		for (Associate associate : strList) {
			System.out.println(associate);
		}
		
		System.out.println("----------------------------------------------");
		
		Collections.sort(strList,new AssociateComparator());
		
		for (Associate associate : strList) {
			System.out.println(associate);
		}
	}
}
