
public class Circle  extends Shape
{
	
	public Circle(int rad, String shapeType) {
		
		super(rad,shapeType);
	}

	@Override
	public float calcArea()
	{
		return (float)(Math.PI*rad*rad);
	}
	public float calcCircumferance()
	{
		return (float)(2*Math.PI*rad);
	}
}
