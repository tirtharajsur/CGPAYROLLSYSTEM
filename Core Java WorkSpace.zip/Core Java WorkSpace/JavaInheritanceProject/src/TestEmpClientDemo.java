
public class TestEmpClientDemo {

	public static void main(String[] args) {
		
		Employee rishabh = new Employee(333,"Rishabh",60000.0F);
		WageEmp shivam = new WageEmp(444,"Shivam",5000.0F,5);
		SalesManager laltu = new SalesManager(555,"laltu",4500.0F,3.0F,75000.0F);
		
		System.out.println(rishabh.dispEmpInfo()+
				"\nMonthly Salary: "+rishabh.calcEmpMonSal()+
				"\nAnnual Salary: "+rishabh.calcEmpAnnualSal());
		System.out.println(shivam.dispWageEmpInfo()+
				"\nMonthly Salary: "+shivam.calcWageEmpMonSal()+
				"\nAnnual Salary: "+shivam.calcWageEmpAnnualSal());
		System.out.println(laltu.dispSalesManagerInfo()+
				"\nMonthly Salary: "+laltu.calcSalesMonSal()+
				"\nAnnual Salary: "+laltu.calcSalesAnnualSal());
	}

}
