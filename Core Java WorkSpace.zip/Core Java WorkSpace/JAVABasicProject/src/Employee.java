
public class Employee 
{

	int empId;
	String empName;
	double empSalary;
	char gender;
	public Employee()
	{
		empId=0;;
		empName="";;
		empSalary=0.0F;;
		gender=' ';
	}
	
	public Employee(int eId,String eName,double eSal,char eGen)
	{
		empId=eId;
		empName=eName;
		empSalary=eSal;
		gender=eGen;
	}
	
	public String dispEmpDetails()
	{
		System.out.println();
		return empId + "-" + empName + "-" + empSalary + "-" +gender;
	}
}
