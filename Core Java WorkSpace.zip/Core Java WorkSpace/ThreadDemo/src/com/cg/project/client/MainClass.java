package com.cg.project.client;

import com.cg.project.threadwork.MyThread;
import com.cg.project.threadwork.RunnableResources;

public class MainClass {
	public static void main(String[] args) throws InterruptedException {
		/*MyThread th1 = new MyThread("tickThread");
		MyThread th2 = new MyThread("tockThread");
		th1.start();
		th2.start();*/
		RunnableResources resource = new RunnableResources();
		Thread th1 = new Thread(resource,"oddThread");
		Thread th2 = new Thread(resource,"evenThread");
		Thread th3 = new Thread(resource,"primeThread");
		th1.start();
		th1.join();
		th2.start();
		th2.join();
		th3.start();
		
		
		
		
	}

}
