
public abstract class Shape 
{
	int rad;
	String shapeType;
	public Shape(int rad,String shapeType)
	{
		this.rad=rad;
		this.shapeType=shapeType;
	}
	public void drawShape()
	{
		System.out.println(shapeType+" Draw with RED color");
	}
	public abstract float calcArea();

}
