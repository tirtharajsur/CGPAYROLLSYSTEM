
public class Date 
{
	static
	{
		System.out.println("In static block of date class");
	}
	int day;
	int month;
	int year;
	static int count;
	
	public Date()
	{
		day=0;month=0;year=0;
		System.out.println("In date empty constructor");
		count++;
	}
	public Date(int dd,int mm,int yy)
	{
		
		this.day = dd;
		this.month =mm;
		this.year =yy;
		
		count++;
	}
	public String dispDate()
	{
		return day+"/"+month+"/"+year;
	}
	public static void getCount()
	{
		System.out.println("No. of Instances: "+count);
	}

}
