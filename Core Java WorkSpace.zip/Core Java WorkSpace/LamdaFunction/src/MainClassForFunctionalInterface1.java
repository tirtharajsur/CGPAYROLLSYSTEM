
public class MainClassForFunctionalInterface1 {

	public static void main(String[] args) {
	/*	WorkService service = () -> System.out.println("Work in Progress");
		callForWork(service);
		callForWork(() -> System.out.println("Work in Progress"));*/
		FunctionalInterface1 ref1=(firstName,lastName) -> System.out.println("goodAfternoon "+firstName+" "+lastName);
		ref1.greeUser("Satish", "Mahajan");

	}
	public static void callForWork(WorkService service) {
		service.doSomeWork();
	}

}
