public enum Seasons
{
	SUMMER,RAINY,WINTER;
	
}
