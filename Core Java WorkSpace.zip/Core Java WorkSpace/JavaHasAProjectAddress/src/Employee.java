
public class Employee 
{
		private int empId;
		private String empName;
		private float empSal;
		private Date empDOJ;
		private Address empAddr;
		
		public Employee()
		{
			empId=0;
			empName=null;
			empSal=0.0F;
			empDOJ=new Date();
			empAddr=new Address();
		}

		
		public Employee(int empId,String empName,float empSal,Date empDOJ,Address empAddr)
		{
			this.empId=empId;
			this.empName=empName;
			this.empSal=empSal;
			this.empDOJ=empDOJ;
			this.empAddr = empAddr;
	
		}
		
		public String dispEmpInfo()
		{
			return "[ID: "+empId+"\nName: "+empName+"\nSalary: "+empSal+"\nDate of Join: "+empDOJ.displayDate()+"]"
					+"\nStreet: "+empAddr.getStreet()+"\nCity: "+empAddr.getCity()+"\nLandMark: "
					+empAddr.getLandMark()+"\nState: "+empAddr.getState()+"\nZipCode: "+empAddr.getZipCode()+"\nCountry:"+empAddr.getCountry();
		}
		
		public float calcAnnualSal()
		{
			return (empSal*12);
		}
}
