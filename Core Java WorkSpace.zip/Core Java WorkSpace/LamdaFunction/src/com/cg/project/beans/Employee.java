package com.cg.project.beans;

public class Employee {
	private int empId,basicSalary;
	private String empname;
	public Employee() {
		super();
	}
	public Employee(int empId, int basicSalary, String empname) {
		super();
		this.empId = empId;
		this.basicSalary = basicSalary;
		this.empname = empname;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + basicSalary;
		result = prime * result + empId;
		result = prime * result + ((empname == null) ? 0 : empname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (basicSalary != other.basicSalary)
			return false;
		if (empId != other.empId)
			return false;
		if (empname == null) {
			if (other.empname != null)
				return false;
		} else if (!empname.equals(other.empname))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", basicSalary=" + basicSalary + ", empname=" + empname + "]";
	}
	

}
