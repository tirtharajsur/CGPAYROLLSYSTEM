
public class Syrup extends Medicine
{
	public Syrup(String medName, float medPrice, String compName)
	{
		super(medName,medPrice,compName);
	}
	
		
	@Override
	public void displayMedicineInfo()
	{
		System.out.println("Syrup [medName=" + medName + ", medPrice=" + medPrice
				+ ", compName=" + compName + "]");
		System.out.println("SHAKE WILL BEFORE USE");
	}



}
