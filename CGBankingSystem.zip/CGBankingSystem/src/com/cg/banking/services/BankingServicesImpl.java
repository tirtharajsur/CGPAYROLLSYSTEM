package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices{
	AccountDAOImpl customerData1 = new AccountDAOImpl();
	Account customer = new Account();
	TransactionDAOImpl transactions = new TransactionDAOImpl();
	private final static float minBalance = 1000;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<minBalance)
			throw new InvalidAmountException();
		Account customer=customerData1.save(new Account(accountType,initBalance));
		transactions.save(customer.getAccountNo(),new Transaction(initBalance,"Deposit") );
		return customer;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = customerData1.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		transactions.save(customers.getAccountNo(),new Transaction(amount,"Deposit") );
		return customers.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers = customerData1.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else if(customers.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customers.getAccountBalance()-amount <=minBalance)
			throw new InsufficientAmountException();
		else
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		transactions.save(customers.getAccountNo(),new Transaction(amount,"Withdraw") );
		return customers.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo = getAccountDetails(accountNoTo);
		Account customerFrom = getAccountDetails(accountNoFrom);
	
		
		if(customerFrom.getAccountBalance()-transferAmount <=minBalance)
			throw new InsufficientAmountException();
		else if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else {
			//withdrawAmount(customerFrom.getAccountNo(), transferAmount, customerFrom.getPinNumber());
			customerFrom.setAccountBalance(customerFrom.getAccountBalance()-transferAmount);
			transactions.save(customerFrom.getAccountNo(),new Transaction(transferAmount,"Withdraw") );
			depositAmount(customerTo.getAccountNo(), transferAmount);
		}
		return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account customers = customerData1.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		return customers;
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> customers = customerData1.findAll();		
		return customers;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {	
		return transactions.findAll(accountNo);
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers = customerData1.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();		
		return customers.getAccountStatus();
	}
}
