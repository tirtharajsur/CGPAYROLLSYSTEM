
public class TestMedicineClient {

	public static void main(String[] args)
	{
		Medicine m1 = new Tablet("O2",50.0F,"Patanjali");
		Medicine m2 = new Syrup("Rantac",18.5F,"GSK");
		Medicine m3 = new Syrup("Zintac",20.0F,"Ayurveda");
		Medicine m4 = new Oinment("Boroline",40.0F,"ITC");
		
		m1.displayMedicineInfo();
		System.out.println();
		m2.displayMedicineInfo();
		System.out.println();
		m3.displayMedicineInfo();
		System.out.println();
		m4.displayMedicineInfo();
	}

}
