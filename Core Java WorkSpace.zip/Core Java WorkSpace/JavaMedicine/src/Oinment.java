
public class Oinment extends Medicine 
{
	public Oinment(String medName, float medPrice, String compName)
	{
		super(medName,medPrice,compName);
	}
	@Override
	public void displayMedicineInfo()
	{
		System.out.println("Oinment [medName=" + medName + ", medPrice=" + medPrice
				+ ", compName=" + compName + "]");
		System.out.println("FOR EXTERNAL USE");
	}

}
