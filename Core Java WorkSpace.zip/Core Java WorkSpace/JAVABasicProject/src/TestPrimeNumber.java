
public class TestPrimeNumber 
{

	public static void main(String[] args)
	{
		int n = Integer.parseInt(args[0]);
		int count = 0;
		for(int i=2;i<n;i++)
		{
			if(n==1)
			{
				System.out.println("1 is not a Prime Number.");
				System.exit(1);
			}
			else if(n%i==0)
			{
				count=1;
				break;
			}
		}
		if(count==0)
			System.out.println(n + " is a Prime number.");
		else if(count==1)
			System.out.println(n + " is not a Prime number.");

	}

}
