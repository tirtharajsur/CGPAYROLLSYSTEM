@FunctionalInterface
public interface FunctionalInterface1 {
	void greeUser(String firstName,String lastName);

}
