
package com.cg.project.threadwork;

public class RunnableResources implements Runnable{
	
	@Override
	public void run() {
		
		Thread t = Thread.currentThread();
		
		if(t.getName().equals("evenThread"))
			for(int i=1;i<=10;i++)
				if(i%2==0)
				System.out.println("Even     "+i+"  "+t.getName());
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		if(t.getName().equals("oddThread"))
			for(int i=1;i<=10;i++)
				if(i%2!=0)
				System.out.println("Odd    "+i+"  "+t.getName());
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(t.getName().equals("primeThread"))
			for(int i=2;i<=10;i++) {
				int flag=1;
				for(int j=2;j<=i/2;j++) {
					if(i%j==0)
						flag=0;
				}
				if(flag==1)
				System.out.println("Prime    "+i+"  "+t.getName());
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		System.out.println("End of Thread Task");
	}
}
