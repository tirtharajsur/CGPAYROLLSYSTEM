package com.cg.project.client;

public class GenClass {
	GenClass<T>
	{
		
	}
	
}
