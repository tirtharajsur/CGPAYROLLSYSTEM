import java.util.Scanner;


public class TestEnumDemo 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Seasons currentSeason = null;
		System.out.println("Enter current season..\n1.SUMMER\n2.RAINY\n3.WINTER" );
		int index = sc.nextInt();
		switch(index)
		{
		case 1 : currentSeason = Seasons.SUMMER;break;
		case 2 : currentSeason = Seasons.RAINY;break;
		case 3 : currentSeason = Seasons.WINTER;
		}
		
		System.out.println("Current Season is: "+currentSeason);
		sc.close();
	}
	

}
