package com.cg.employees.bean;

public class Employee {
	private int empId;
	private double salary;
	private String firstName;
	private String lastName;
	public Employee() {
		super();
	}
	
	public Employee(int empId, String firstName, String lastName, double salary) {
		super();
		this.empId = empId;
		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public boolean equals(Employee e) {
		System.out.println("Employee 1st equal method");
		return true;
	}
	public boolean equals(Object obj) {
		System.out.println("Employee 1st equal method");
		return true;
	}

	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	

}
