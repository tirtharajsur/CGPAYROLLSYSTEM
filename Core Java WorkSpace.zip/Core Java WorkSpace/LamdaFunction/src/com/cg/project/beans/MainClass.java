package com.cg.project.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111, 12000, "Pritam"));
		empList.add(new Employee(112,22000,"Kutta"));
		empList.add(new Employee(113,22000,"Raj"));
		empList.add(new Employee(114,22000,"Khacchhor"));
		empList.add(new Employee(115, 20000,"Nikesh"));
		empList.add(new Employee(116,21000,"Nyalakhyapa"));
		
		/*Comparator<Employee> comparator = (emp1,emp2)->emp1.getBasicSalary()-emp2.getBasicSalary();
		Collections.sort(empList,comparator);
		Collections.sort(empList,(e1,e2)->e1.getBasicSalary()-e2.getBasicSalary());
		
		printEmployeeDetailsPredicate(empList,(employee)->employee.getEmpname().startsWith("K"));
		System.out.println("............................................................................................................");
		printEmployeeDetailsPredicate(empList,(employee)->{
			return employee.getBasicSalary()>10000?true:false;
			});
		
	}
	private static void printEmployeeDetailsPredicate(List<Employee>empList,Predicate<Employee> condition) {
		for(Employee employee:empList)
			if(condition.test(employee))
				System.out.println(employee);
			*/
		
		Stream<Employee> stream1 = empList.stream();
		Stream<Employee> stream2 =((Stream<Employee>)empList).distinct();
		Stream<Employee> stream3 = stream2.filter((employee)->employee.getEmpname().startsWith("N"));
		System.out.println(stream3.count());
		stream3.forEach(employee->employee.getEmpname().startsWith("N"));
		System.out.println(empList.stream().map(employee->employee.getBasicSalary()));
		
	}
		

}
