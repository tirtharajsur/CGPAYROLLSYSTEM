package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

import org.junit.Assert;

public class MathServicesTest {

private static MathServices services;

@BeforeClass
public static void setUpTestEnv() {
	services = new MathServicesImpl();
}

//Test for addition
@Test(expected=NegativeNumberException.class)
public void testAddForFirstNumberNegative()throws NegativeNumberException{
	services.add(-100, 200);
}

@Test(expected=NegativeNumberException.class)
public void testAddForSecondNumberNegative()throws NegativeNumberException{
	services.add(100, -200);
}

@Test(expected=NegativeNumberException.class)
public void testAddForBothNumbervalid()throws NegativeNumberException{
	Assert.assertEquals(300,services.add(100, 200));
	
}

//Test for Subtraction
@Test(expected=NegativeNumberException.class)
public void testSubForFirstNumberNegative()throws NegativeNumberException{
	services.sub(-100, 200);
}

@Test(expected=NegativeNumberException.class)
public void testSubForSecondNumberNegative()throws NegativeNumberException{
	services.sub(100, -200);
}

@Test(expected=NegativeNumberException.class)
public void testSubForBothNumberValid()throws NegativeNumberException{
	Assert.assertEquals(100,services.sub(200, 100));
}

//test for Multiplication
@Test(expected=NegativeNumberException.class)
public void testMultiForFirstNumberNegative()throws NegativeNumberException{
	services.multi(-100, 200);
}

@Test(expected=NegativeNumberException.class)
public void testMultiForSecondNumberNegative()throws NegativeNumberException{
	services.multi(100, -200);
}
@Test(expected=NegativeNumberException.class)
public void testMultiForBothNumberValid()throws NegativeNumberException{
	int expectedAns=20000;
	int actualAns=services.multi(100, 200);
	Assert.assertEquals(expectedAns,actualAns);
	
}


@Test(expected=NegativeNumberException.class)
public void testDivForFirstNumberNegative()throws NegativeNumberException{
	services.div(-100, 200);
}

@Test(expected=NegativeNumberException.class)
public void testDivForSecondNumberNegative()throws NegativeNumberException{
	services.div(100, -200);
}
@Test
public void testDivForBothNumberValid()throws NegativeNumberException{
	int expectedAns=2;
	int actualAns=services.div(200, 100);
	Assert.assertEquals(expectedAns,actualAns);
	
}

@AfterClass
public static void tearDownTestEnv() {
	services = null;
}
	
}
