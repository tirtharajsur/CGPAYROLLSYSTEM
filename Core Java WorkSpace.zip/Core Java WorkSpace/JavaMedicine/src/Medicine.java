
public class Medicine {
	
	String medName;
	float medPrice;
	String compName;
	
	public Medicine()
	{
		
	}

	public Medicine(String medName, float medPrice, String compName) {
		super();
		this.medName = medName;
		this.medPrice = medPrice;
		this.compName = compName;
	}

	public void displayMedicineInfo()
	{
		
	}

	@Override
	public String toString() {
		return "Medicine [medName=" + medName + ", medPrice=" + medPrice
				+ ", compName=" + compName + "]";
	}

}
