package com.cg.project.innerdemo.client;

public interface ProjectServices {
	public void developProject();

}
