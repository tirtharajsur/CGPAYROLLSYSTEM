
public class MainClass {

	public static void main(String[] args) {
		
		int n = 10;
		Integer num1 = new Integer(n);
		Integer num2 = num1+100;
		if(num1.equals(n))
			System.out.println("Same");
		else
			System.out.println("not same");
		System.out.println("Value of num2: "+num2+"(Unboxing and autoboxing done)");
		System.out.println(num1);
	}

}
