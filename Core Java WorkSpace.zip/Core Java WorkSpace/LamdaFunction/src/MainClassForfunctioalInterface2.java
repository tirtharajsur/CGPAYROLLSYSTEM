
public class MainClassForfunctioalInterface2 {

	public static void main(String[] args) {
		
		FunctionalInterface2 ref2 = (a,b) ->a+b;
		System.out.println("sum is:"+ref2.add(2, 2));
	}
	public static void callForWork(WorkService service) {
		service.doSomeWork();
	}

}
