
class Calculator 
{
	public int add(int num1, int num2)
	{
		return (num1+num2);
	}
	public String add(String fn, String ln)
	{
		return (fn+ln);
	}
	public int add(byte num1, byte num2)
	{
		return (num1+num2);
	}
	public void add(byte num1, byte num2, byte num3)
	{
		System.out.println("Byte addition is = " +(num1+num2+num3));
	}
	public void add(float num1, float num2)
	{
		System.out.println("Float addition is = " +(num1+num2));
	}

}

public class TestCalculatorDemo
{
	public static void main(String[] args) 
	{
		Calculator c = new Calculator();
		System.out.println("Integer addition is = " + c.add(40,60));
		System.out.println("Byte addition is = " + c.add((byte)40,(byte)60));
		System.out.println("String addition is = " + c.add("Daipayan", "Guha"));
		c.add((byte)40,(byte)60,(byte)10);
		c.add(10.0F,20.0F);

	}
}