
public class WageEmp extends Employee
{
	int noOfHour;
	static int ratePerHour;
	static
	{
		ratePerHour = 500;
	}
	public WageEmp()
	{
		
	}
	public WageEmp(int empId,String empName,float empBasicSal,
			int noOfHour)
	{		
		/*this.empId=empId;
		this.empName=empName;
		this.empBasicSal=empBasicSal;*/
		super(empId,empName,empBasicSal);
		this.noOfHour = noOfHour;
	}
	
	@Override
	public String dispEmpInfo()
	{
		return "WageEmp Info ["+super.dispEmpInfo()+"[noOfHour=" + noOfHour + "]";
	}
	public float calcEmpMonSal()
	{
		return empBasicSal+(noOfHour*ratePerHour*20);
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpMonSal()*12;
	}
	
}
