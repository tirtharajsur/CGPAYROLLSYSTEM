
public class WageEmp extends Employee
{
	int noOfHour;
	static int ratePerHour;
	static
	{
		ratePerHour = 500;
	}
	public WageEmp()
	{
		
	}
	public WageEmp(int empId,String empName,float empBasicSal,
			int noOfHour)
	{		
		this.empId=empId;
		this.empName=empName;
		this.empBasicSal=empBasicSal;
		this.noOfHour = noOfHour;
	}
	public String dispWageEmpInfo()
	{
		return "WageEmp Info ["+super.dispEmpInfo()+"[noOfHour=" + noOfHour + "]";
	}
	public float calcWageEmpMonSal()
	{
		return empBasicSal+(noOfHour*ratePerHour*20);
	}
	public float calcWageEmpAnnualSal()
	{
		return calcWageEmpMonSal()*12;
	}
	
}
