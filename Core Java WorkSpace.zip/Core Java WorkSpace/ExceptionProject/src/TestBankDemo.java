import java.util.Scanner;

class Account
{
	private int accountNo;
	private int currBalance;
	
	public Account(int currBalance) {
		super();
		this.currBalance = currBalance;
	}

	public void withdraw(int withdrawAmt)
	{
		if(currBalance >=withdrawAmt)
		{
			currBalance = currBalance - withdrawAmt;
			System.out.println("You can Withdraw: "+withdrawAmt);
			System.out.println("After Withdrawl, Current Balance is:"+currBalance);
		}
		else
		{
			throw new LowBalanceException(
					"less Balance in oyur Account");
		}
	}
	
}
public class TestBankDemo {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("What is the current account: ");
		int currBal = sc.nextInt();
		Account Tirtha = new Account(currBal);
		System.out.println("Enter Withdraw Amount: ");
		int withAmt = sc.nextInt();
		try{
			Tirtha.withdraw(withAmt);
		}
		catch(LowBalanceException e)
		{
			throw new LowBalanceException("Less Balance in your Account!");
		}
		
	}

}
