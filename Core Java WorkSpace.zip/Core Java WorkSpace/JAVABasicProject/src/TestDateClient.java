
public class TestDateClient 
{
	static
	{
		System.out.println("This is Static block of TestDateClient");
	}
	public static void main(String[] args) 
	{
		System.out.println("Main starts from here...");
		Date ishanDOJ = new Date();

		System.out.println("IshanDOJ is : " + ishanDOJ.dispDate());
		
		System.out.println("--------------");
		Date daipayanDOJ = new Date(22,01,2019);
		System.out.println("DaipayanDOJ is : " + daipayanDOJ.dispDate());
		
		Date rohanDOJ = new Date(22,01,2019);
		System.out.println("RohanDOJ is : " + rohanDOJ.dispDate());
		
		
		Date.getCount();


	}

}
