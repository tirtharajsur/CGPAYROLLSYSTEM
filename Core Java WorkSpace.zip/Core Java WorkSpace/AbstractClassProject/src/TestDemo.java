import java.util.Scanner;


public class TestDemo 
{
	public static void mai(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		Shape shaps[] = new Shape[4];
		int choice;
		int i;
		for(i=0;i<4;i++)
		{
			System.out.println("What shape do you want: ");
			System.out.println("1.Circle\n2.Sphere\nEnter your choice: ");
			choice = sc.nextInt();
			System.out.println("Enter the Radius: ");
			int rad = sc.nextInt();
			
			switch(choice)
			{
			case 1:	shaps[i] = new  Circle(rad,"Circle");
							break;
			case 2:	shaps[i] = new  Sphere(rad,"Sphere");
							break;
			default:	shaps[i] = new  Circle(rad,"Circle");
							shaps[i].drawShape();
			}
		}
		
		System.out.println("*--------------------------------------*");
		
		for(int j = 0;j<shaps.length;j++)
		{
			shaps[j].drawShape();
			if(shaps[j] instanceof Sphere)
			{
				System.out.println("*********Sphere**********");
				shaps[j].calcArea();
				((Sphere)shaps[j]).calcVolume();
			}
			else if(shaps[j] instanceof Circle)
			{
				
				
				System.out.println("**********Circle***********");
				shaps[j].calcArea();
				((Circle)shaps[j]).calcCircumferance();
			}
			
		}

	}
}
