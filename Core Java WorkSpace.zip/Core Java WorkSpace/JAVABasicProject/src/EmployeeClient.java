import java.util.Scanner;


public class EmployeeClient 
{
	public static void main(String[] args)
	{
		Scanner sc  = new Scanner(System.in);
		System.out.println("Enter how many employee's details to be entered: ");
		int num = sc.nextInt();
		Employee emps[] = new Employee[num];
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println("Enter your Employee Id:");
			int id = sc.nextInt();
			System.out.println("Enter your Employee Name:");
			String nm = sc.next();
			System.out.println("Enter your Salary:");
			float sal = sc.nextFloat();
			System.out.println("Enter your Gender: ");
			char gen = sc.next().charAt(0);
			emps[i]=new Employee(id,nm,sal,gen);
			System.out.println("------\nNext Employee\n------");
			
			
		}
		
		for(int i=0;i<emps.length;i++)
		{
			System.out.println(emps[i].dispEmpDetails());
		}
	}
	
}
