
public class SalesManager extends WageEmp 
{
	float commission;
	float salesAmount;

	public SalesManager(int empId,String empName,float empBasicSal,
			float commission,float salesAmount) 
	{
		this.empId=empId;
		this.empName=empName;
		this.empBasicSal=empBasicSal;
		this.commission = commission;
		this.salesAmount = salesAmount;
	}
	
	@Override
	public String dispEmpInfo()
	{
		return "SalesManager Info ["+super.dispEmpInfo()+"[Commission=" + commission +"% Sales Amount="+salesAmount+"]";
		
	}
	
	public float calcEmpMonSal()
	{
		return empBasicSal+((float)(commission/100)*salesAmount);
	}
	
	public float calcEmpAnnualSal()
	{
		return calcEmpMonSal()*12;
	}
	
	
	
}
