
public interface WorkService {
	public void doSomeWork();
}
