package com.cg.project.threadwork;

public class MyThread extends Thread{
	
	public MyThread(String name) {
		super(name);
	}
	
	@Override
	public void run() {
		if(this.getName().equals("tickThread"))
			for(int i=1;i<=10;i++)
				System.out.println("Tick     "+i+this.getName());
		
		if(this.getName().equals("lockThread"))
			for(int i=1;i<=10;i++)
				System.out.println("Tock     "+i+this.getName());
		
		System.out.println("End of Thread Task");
	}

}
