enum Gender
{
	M,F;
}
public class Employee
{
	private int empId;
	private String empName;
	private double empSalary;
	private Gender gender;
	
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
		public void setEmpName(String empName) {
		this.empName = empName;
	}
		public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public Gender getGender() {
		return gender;
	}
	
}
