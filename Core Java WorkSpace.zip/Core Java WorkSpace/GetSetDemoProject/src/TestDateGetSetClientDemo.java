
public class TestDateGetSetClientDemo {

	public static void main(String[] args) 
	{
		Date d1 = new Date();
		d1.setDay(20);
		d1.setMonth(03);
		d1.setYear(2000);
		
		Date d2 = new Date();
		d2.setDay(15);
		d2.setMonth(04);
		d2.setYear(2001);
		
		Date d3 = new Date();
		d3.setDay(25);
		d3.setMonth(10);
		d3.setYear(2005);
		
		System.out.println("d1 Date of Join: "+d1.getDay()+"/"+
				d1.getMonth()+"/"+
				d1.getYear());
		System.out.println("d2 Date of Join: "+d2.getDay()+"/"+
				d2.getMonth()+"/"+
				d2.getYear());
		System.out.println("d3 Date of Join: "+d3.getDay()+"/"+
				d3.getMonth()+"/"+
				d3.getYear());

	}

}
