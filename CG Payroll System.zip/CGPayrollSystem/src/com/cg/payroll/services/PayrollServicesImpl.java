package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices{
private AssociateDAO  associateDao = new AssociateDAOImpl(); 
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber,String bankName, String ifscCode) {
	Associate associate = new Associate( yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
	associate = associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		return 12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("Associate details not found for Id"+associateId);
		return associate;
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		
		return associateDao.findAll();
	}
	@Override
	public double calculateGrossSalary(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate = getAssociateDetails(associateId);
		return (int) (associate.getSalary().getBasicSalary()
				+3*associate.getSalary().getBasicSalary()*2
				+0.25*associate.getSalary().getBasicSalary()
				+0.2*associate.getSalary().getBasicSalary()
				+associate.getSalary().getCompanyPf()
				+associate.getSalary().getEpf());
	}
}
