
public class Tablet extends Medicine 
{

	public Tablet(String medName, float medPrice, String compName)
	{
		super(medName,medPrice,compName);
	}
		
	@Override
	public void displayMedicineInfo()
	{
		
		System.out.println("Tablet [medName=" + medName + ", medPrice=" + medPrice
				+ ", compName=" + compName + "]");
		System.out.println("KEEP IN COOL AND DRY PLACE");
	}

	
	
	

}
