package com.cg.mathproject.client;

public class MainClass {

	public static void main(String[] args) {


	}

}
