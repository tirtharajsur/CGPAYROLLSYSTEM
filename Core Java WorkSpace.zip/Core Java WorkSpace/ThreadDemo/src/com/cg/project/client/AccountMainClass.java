package com.cg.project.client;

import com.cg.project.threadwork.Customer;

public class AccountMainClass {

	public static void main(String[] args) {
		Thread t1 = new Thread(new Customer(),"rahul");
		Thread t2 = new Thread(new Customer(),"anil");
		Thread t3 = new Thread(new Customer(),"satish");
		t1.start();
		t1.setPriority(Thread.MAX_PRIORITY);
		t2.start();
		t3.start();
		}

}
