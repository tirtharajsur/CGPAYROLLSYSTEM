import java.util.*;
public class TestdataTypesDemo 
{

	public static void main(String[] args) 
	{
		byte b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Number :");
		b = sc.nextByte();
		System.out.println("b = " + b);

	}

}
