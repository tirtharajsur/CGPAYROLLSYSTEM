
public class MainClassVer2 {

	public static void main(String[] args) {
		WorkService service = () -> System.out.println("Work in Progress");
		callForWork(service);
		callForWork(() -> System.out.println("Work in Progress")); 

	}
	public static void callForWork(WorkService service) {
		service.doSomeWork();
	}

}
