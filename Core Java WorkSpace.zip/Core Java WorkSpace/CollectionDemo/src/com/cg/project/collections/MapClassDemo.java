package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

import com.cg.project.beans.Associate;

public class MapClassDemo {

	public static void main(String[] args) {
		Hashtable<Integer,Associate> associates  = new Hashtable<>();
		associates.put(111,new Associate(111,"Zakir","Khan",15000.00));
		associates.put(112,new Associate(222,"Varun","Thakur",16001.00));
		associates.put(113,new Associate(333,"Rahul","Subramanian",17002.00));
		associates.put(114,new Associate(444,"Tanmay","Bhat",18003.00));
		
		Associate associate = associates.get(112);
		
		associates.remove(112);
		
		Set<Integer>keys = associates.keySet();
		
		for (Integer key : keys) {
			System.out.println(associates.get(key));
		}
		
		ArrayList<Associate> associateList = new ArrayList<>(associates.values());
	}

}
