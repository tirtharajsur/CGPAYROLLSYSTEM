
public class Employee 
{
	int empId;
	String empName;
	float empBasicSal;
	public Employee()
	{
		
	}
	public Employee(int empId, String empName, float empBasicSal) 
	{
		this.empId = empId;
		this.empName = empName;
		this.empBasicSal = empBasicSal;
	}
	
	
	public String dispEmpInfo()
	{
		return "Employee info [empId=" + empId + ", empName=" + empName
				+ ", empBasicSal=" + empBasicSal + "]";
	}
	
	public float calcEmpMonSal()
	{
		return empBasicSal;
	}
	
	public float calcEmpAnnualSal()
	{
		return empBasicSal*12;
	}
	
}
