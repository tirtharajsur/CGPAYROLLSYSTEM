
public class TestLoopDemo {

	public static void main(String[] args) 
	{
		greetMe();
		for(int i=0;i<5;i++)
		{
			System.out.println("i = "+i);
		}

	}
	public static void greetMe()
	{
		System.out.println("Hello All");
	}
	public void sayHello()
	{
		greetMe();
	}

}
