
public class TestDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "Daipayan Guha";
		System.out.println("Welcome to Capgemini." + name);

	}

}
class Hello
{
	public static void main(String args[])
	{
		System.out.println("Hello said Hi");
	}
}