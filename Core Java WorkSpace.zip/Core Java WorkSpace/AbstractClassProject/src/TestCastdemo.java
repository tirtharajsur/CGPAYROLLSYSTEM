
public class TestCastdemo {

	public static void main(String[] args) {
		Shape cir1 = new Circle(4,"Circle");
		Circle cir2 = new Circle(2,"circle");
		Shape cir3 = cir1;
		Circle cir4 = (Circle)cir1;
		
		Shape sph1 = new Sphere(4,"Sphere");
		Shape sph2 = new Sphere(2,"Sphere");
		Shape sph3 = sph1;
		Shape sph4 = (Sphere)sph1;
		
		//cir1.drawShape();
		//cir1.calcArea();
		//cir2.calcCircumferance();
		//((Circle)cir1).calcCircumferance();
		
		
		//Shape sh[] = new Shape[2];
		//sh[0] = new Circle(4,"Circle");
		//sh[1] = new Sphere(4,"Sphere");
		
		//sh[0].calcArea();
		//((Circle)sh[0]).calcCircumferance()
		
		if(cir2 instanceof Circle)
		{
			System.out.println("Yes I am a Circle");
		}
		else
		{
			System.out.println("No I am not a Circle");
		}
		
		if(cir2 instanceof Shape)
		{
			System.out.println("Yes I am a Shape");
		}
		else
		{
			System.out.println("No I am not a Shape");
		}
		if(cir3 instanceof Sphere)
		{
			System.out.println("yes I am a Sphere");
		}
		else
		{
			System.out.println("No I am not a Sphere");
		}
	}

}
