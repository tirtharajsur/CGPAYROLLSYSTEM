import java.util.Scanner;


public class TestEmpClient {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Emp Id: ");
		int eId = sc.nextInt();
		
		System.out.println("Enter Name: ");
		String name = sc.next();
		
		System.out.println("Enter Emp Salary: ");
		float sal = sc.nextFloat();
		
		System.out.println("Enter day of Joining: ");
		int dd = sc.nextInt();
		
		System.out.println("Enter month of Joining: ");
		int mm = sc.nextInt();
		
		System.out.println("Enter year of Joining: ");
		int yy = sc.nextInt();
		
		Address Tirtha = new Address();
		Tirtha.setStreet("8C/88,Beleghata");
		Tirtha.setCity("Kolkata");
		Tirtha.setLandMark("NUJS");
		Tirtha.setZipCode(700010);
		Tirtha.setState("West Bengal");
		Tirtha.setCountry("India");
		
		Date TirtharajDOJ = new Date(dd,mm,yy);
		Employee Tirtharaj = new Employee(eId,name,sal,TirtharajDOJ,Tirtha);
		System.out.println(Tirtharaj.dispEmpInfo());
		System.out.println("Tirtharaj's Annual Salary is: "+Tirtharaj.calcAnnualSal());
		
		
		
		

	}

}
