package com.cg.employees.main;

import com.cg.employees.bean.Employee;
public class MainClass {

	public static void main(String[] args) {
		Employee emp1 = new Employee(111,"Daipayan","Guha",18500.00);
		Employee emp2 = new Employee(111,"Daipayan","Guha",18500.00);
		
		Object obj = emp2;
		
		if(emp1.equals(emp2))
		{
			System.out.println("1st equal method called");
		}
			
		else
		{
			System.out.println("1st equal method not called");
		}
		
		if(obj.equals(emp2))
		{
			System.out.println("2nd equal method called");
		}
			
		else
		{
			System.out.println("2nd equal method not called");
		}
		


	}

}
