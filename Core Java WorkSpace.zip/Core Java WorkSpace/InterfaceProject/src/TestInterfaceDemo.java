
public class TestInterfaceDemo 
{
	public static void main(String[] args)
	{
		/*Printable pp = new Person("Tirtharaj Sur","APK198THR");
		System.out.println(pp.print());
		System.out.println(((Person)pp).sayHi());*/
		
		Printable pp[] = new Printable[2];
		
		pp[0] = new Person("Tirtharaj Sur","APK485GHF");
		pp[1] = new Person("aaaaa","APK364HFJ");
		System.out.println(pp[0].print());
		System.out.println(((Person)pp[0]).sayHi());
		
		System.out.println(pp[1].print());
		System.out.println(((Person)pp[1]).sayHi());
	}

}
