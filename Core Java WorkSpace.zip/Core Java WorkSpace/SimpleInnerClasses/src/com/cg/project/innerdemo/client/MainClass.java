package com.cg.project.innerdemo.client;

public class MainClass {

	public static void main(String[] args) {
		ProjectServices services = new ProjectServices() {
			
			@Override
			public void developProject() {
				System.out.println("IT Project has developed.");
				
			}
		};

	}

}
