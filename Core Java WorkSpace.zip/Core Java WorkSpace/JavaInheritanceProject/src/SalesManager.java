
public class SalesManager extends WageEmp 
{
	float commission;
	float salesAmount;

	public SalesManager(int empId,String empName,float empBasicSal,
			float commission,float salesAmount) 
	{
		this.empId=empId;
		this.empName=empName;
		this.empBasicSal=empBasicSal;
		this.commission = commission;
		this.salesAmount = salesAmount;
	}
	public String dispSalesManagerInfo()
	{
		return "SalesManager Info ["+super.dispEmpInfo()+"[Commission=" + commission +"% Sales Amount="+salesAmount+"]";
		
	}
	
	float calcSalesMonSal()
	{
		return empBasicSal+((float)(commission/100)*salesAmount);
	}
	
	public float calcSalesAnnualSal()
	{
		return calcSalesMonSal()*12;
	}
	
	
	
}
