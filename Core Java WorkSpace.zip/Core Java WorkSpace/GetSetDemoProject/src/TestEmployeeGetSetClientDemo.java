
public class TestEmployeeGetSetClientDemo {

	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.setEmpId(101);
		e1.setEmpName("Doi");
		e1.setEmpSalary(12000);
		e1.setGender(Gender.F);
		
		Employee e2 = new Employee();
		e2.setEmpId(102);
		e2.setEmpName("Bhola");
		e2.setEmpSalary(12001);
		e2.setGender(Gender.M);

		
		System.out.println("Employee Id: "+ e1.getEmpId()+
				"\nEmployee Name: "+ e1.getEmpName()+
				"\nEmployee Salary: "+e1.getEmpSalary()+
				"\nEmployee Gender: "+e1.getGender());
		System.out.println("-----");
		System.out.println("Employee Id: "+ e2.getEmpId()+
				"\nEmployee Name: "+ e2.getEmpName()+
				"\nEmployee Salary: "+e2.getEmpSalary()+
				"\nEmployee Gender: "+e2.getGender());

	}

}
