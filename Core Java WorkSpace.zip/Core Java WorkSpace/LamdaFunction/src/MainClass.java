import java.util.function.Consumer;
public class MainClass {

	public static void main(String[] args) {
		WorkService service = new WorkService() {
			
			@Override
			public void doSomeWork() {
				// TODO Auto-generated method stub
				System.out.println("Work in Progress");
				System.out.println("Finally work is done.");
			}
		};
		
		service.doSomeWork();
		
		WorkService service2 = () -> {
			System.out.println("Work in Progress");
			System.out.println("Finally work is done.");
		};
		service2.doSomeWork();
	}

}
