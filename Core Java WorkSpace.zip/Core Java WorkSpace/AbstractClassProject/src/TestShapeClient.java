import java.util.Scanner;


public class TestShapeClient {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		Shape shaps[] = new Shape[4];
		int choice;
		int i;
		for(i=0;i<4;i++)
		{
			System.out.println("What shape do you want: ");
			System.out.println("1.Circle\n2.Sphere\nEnter your choice: ");
			choice = sc.nextInt();
			System.out.println("Enter the Radius: ");
			int rad = sc.nextInt();
			
			switch(choice)
			{
			case 1:
				shaps[i]=new Circle(rad,"Circle");
				shaps[i].drawShape();
				System.out.println("Area: "+shaps[i].calcArea());
				System.out.println("Circumferance: "+((Circle) shaps[i]).calcCircumferance());
				break;
			case 2:
				shaps[i]=new Sphere(rad,"Sphere");
				shaps[i].drawShape();
				System.out.println("Area: "+shaps[i].calcArea());
				System.out.println("Sphere: "+((Sphere)shaps[i]).calcVolume());
				break;
			default:
				shaps[i]=new Circle(rad,"Circle");
				shaps[i].drawShape();
				System.out.println(shaps[i].calcArea());
				break;
				
				
			}
		}

	}

}
