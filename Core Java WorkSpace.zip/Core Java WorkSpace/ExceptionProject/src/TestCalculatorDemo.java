import java.util.Scanner;

class Calculator
{
	int num1;
	int num2;
	int result;
	public Calculator(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	public int divide() 
	{
		int numbers[] = new int[2];
		numbers[0] = num1;
		numbers[1]= num2;
		System.out.println("The Numbers are: "+numbers[0]+" & " +numbers[1]);
		try
		{
			result = numbers[0]/numbers[1];
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
	
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		finally
		{
			System.out.println("This part is always executed");
		}
		System.out.println("Division is done successfully!");
		return result;
	}
}
public class TestCalculatorDemo {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Numbers:");
		int n1 = sc.nextInt();
		int n2 = sc.nextInt();
		Calculator cc =new Calculator(n1,n2);
		System.out.println("The Division : "+cc.divide());
		

	}

}
