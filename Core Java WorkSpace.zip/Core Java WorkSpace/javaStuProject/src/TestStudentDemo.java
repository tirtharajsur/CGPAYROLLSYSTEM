import com.cg.bat.*;
import com.cg.stu.Student;
public class TestStudentDemo {

	public static void main(String[] args)
	{
		Batch javaBat = new Batch();
		javaBat.setBatchCode("JEE001");
		javaBat.setBatchName("Java Full Stack 16th jan Batch");
		javaBat.setFacultyName("Anjulata Tembhare");
		javaBat.setBatchTime("8:30 AM to 6:00 PM");
		
		Batch dotnet = new Batch();
		dotnet.setBatchCode("JEE001");
		dotnet.setBatchName("Java Full Stack 16th jan Batch");
		dotnet.setFacultyName("Anjulata Tembhare");
		dotnet.setBatchTime("8:30 AM to 6:00 PM");
		
		Student javaStu1 = new Student(444,"Roshan",javaBat);
		Student javaStu2 = new Student(777,"Shyam",javaBat);
		Student javaStu3 = new Student(999,"Anita",dotnet);
		System.out.println(javaStu1.dispStuInfo());
		System.out.println(javaStu2.dispStuInfo());
		System.out.println(javaStu3.dispStuInfo());
	}

	private static Object dispStuInfo() {
		return null;
	}

}
