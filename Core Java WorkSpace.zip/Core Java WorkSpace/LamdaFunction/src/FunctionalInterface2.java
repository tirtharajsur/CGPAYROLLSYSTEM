
public interface FunctionalInterface2 {
	public int add(int a,int b);

}
