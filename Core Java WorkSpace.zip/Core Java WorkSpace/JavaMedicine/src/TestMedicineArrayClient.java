import java.util.Scanner;


public class TestMedicineArrayClient {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		String medName;
		float medPrice;
		String compName;
		
		System.out.println("Enter the Number of Medicines: ");
		int num = sc.nextInt();
		Medicine medArray[] = new Medicine[num];
		for(int i=0;i<num;i++)
		{
			System.out.println("..........MENU..........");
			System.out.println("1.Tablet\n2.Syrup\n3.Oinment");
			System.out.println("Enter your choice: ");
			int ch = sc.nextInt();
			switch(ch)
			{
			case 1: 
				System.out.println("Enter Tablet Name: ");
				medName= sc.next();
				System.out.println("Enter Tablet Price: ");
				medPrice = sc.nextFloat();
				System.out.println("Enter Tablet Company: ");
				compName = sc.next();
				
				medArray[i] = new Tablet(medName,medPrice,compName);
				
				break;
				
			case 2:
				System.out.println("Enter Syrup Name: ");
				medName= sc.next();
				System.out.println("Enter Syrup Price: ");
				medPrice = sc.nextFloat();
				System.out.println("Enter Syrup Company: ");
				compName = sc.next();
				
				medArray[i] = new Tablet(medName,medPrice,compName);
				
				break;
				
			case 3:
				System.out.println("Enter Oinment Name: ");
				medName= sc.next();
				System.out.println("Enter Oinment Price: ");
				medPrice = sc.nextFloat();
				System.out.println("Enter Oinment Company: ");
				compName = sc.next();
				
				medArray[i] = new Tablet(medName,medPrice,compName);
				
				break;
				
			default:
				System.out.println("Invalid Choice");

			
			}
			
		}
		System.out.println("Displaying Details.....");
		
		for(int j=0;j<num;j++)
		{
			medArray[j].displayMedicineInfo();
		}
		
		
	}

}
