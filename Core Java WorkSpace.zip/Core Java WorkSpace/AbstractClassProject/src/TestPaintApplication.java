
public class TestPaintApplication {

	public static void main(String[] args) 
	{
		Circle circle1 = new Circle(6,"Circle");
		Circle circle2 = new Circle(4,"Circle");
		Shape circle3 = new Circle(3,"Circle");
		Sphere sph4 = new Sphere(2,"Sphere");
		
		circle1.drawShape();
		System.out.println(" Area of circle: "+circle1.calcArea());
		
		circle2.drawShape();
		System.out.println(" Area of circle: "+circle2.calcArea());
		
		circle3.drawShape();
		System.out.println(" Area of circle: "+circle3.calcArea());
		
		sph4.drawShape();
		System.out.println("Area of Sphere: "+sph4.calcArea());
		System.out.println("Volume of Sphere: "+sph4.calcVolume());
		
		
		

	}

}
