package com.cg.banking.daoservices;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;
public class TransactionDAOImpl implements TransactionDAO{
	@Override
	public Transaction save(long accountNo,Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getACCOUNT_ID_COUNTER());
		BankingDBUtil.customerDetails.get(accountNo).getTransaction().put((long) transaction.getTransactionId(),transaction);	
		return transaction;
	}
	@Override
	public boolean update(Transaction transaction) {	
		return false;
	}
	@Override
	public Transaction findOne(long accountNo,int transactionId) {		
		return BankingDBUtil.customerDetails.get(accountNo).getTransaction().get(transactionId);
	}
	@Override
	public List<Transaction> findAll(long accountNo) {
		return new ArrayList<Transaction>(BankingDBUtil.customerDetails.get(accountNo).getTransaction().values());
	}
}
