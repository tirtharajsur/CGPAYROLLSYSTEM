package com.cg.project.collections;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;

import com.cg.project.beans.Associate;

public class HashSetClassDemo {
	public static void main(String[] args) {
		HashSet<Associate> strList  = new HashSet<>();
		strList.add(new Associate(111,"Zakir","Khan",15000.00));
		strList.add(new Associate(222,"Varun","Thakur",16001.00));
		strList.add(new Associate(333,"Rahul","Subramanian",17002.00));
		strList.add(new Associate(444,"Tanmay","Bhat",18003.00));
		
		//Collections.sort(strList);
		for (Associate associate : strList) {
			System.out.println(associate);
		}
		
		System.out.println("----------------------------------------------");
		
		//Collections.sort(strList,new AssociateComparator());
		
		for (Associate associate : strList) {
			System.out.println(associate);
		}
	}

}
