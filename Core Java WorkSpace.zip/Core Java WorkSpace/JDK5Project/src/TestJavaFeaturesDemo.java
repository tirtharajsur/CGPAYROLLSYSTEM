class Calculator
{
	public int add(int ... nums)
	{
		int sum  = 0;
		for(int j = 0;j<nums.length;j++)
		{
			sum = sum+nums[j];
		}
		
		return sum;
	}
}
public class TestJavaFeaturesDemo {

	public static void main(String[] args) 
	{
		Calculator cc = new Calculator();
		System.out.println("Sumation is: "+cc.add(90,80,10,5,12,15));
		System.out.println("PI Value: "+Math.PI);
		
		System.out.println("***************ENHANCE FOR LOOP*****************");
		int nums[] = new int[4];
		nums[0]=90;
		nums[1]=45;
		nums[2]=23;
		nums[3]=89;
		
		for(int temp:nums)
		{
			System.out.println(" "+temp);
		}

	}

}
