
public class LowBalanceException extends RuntimeException
{
	public LowBalanceException(String msg)
	{
		super(msg);
	}

	public LowBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
